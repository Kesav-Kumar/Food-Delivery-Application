export class AdminLoginRequest {
    public username: string ="";
    public password: string ="";
}
