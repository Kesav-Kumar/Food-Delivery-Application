export class UserLoginRequest {
    public username: string ="";
    public password: string ="";
}
