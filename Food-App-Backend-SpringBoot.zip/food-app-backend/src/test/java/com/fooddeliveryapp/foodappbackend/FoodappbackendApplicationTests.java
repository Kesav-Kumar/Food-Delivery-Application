package com.fooddeliveryapp.foodappbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodappbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
