package com.fooddeliveryapp.foodappbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodAppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodAppBackendApplication.class, args);
	}

}
