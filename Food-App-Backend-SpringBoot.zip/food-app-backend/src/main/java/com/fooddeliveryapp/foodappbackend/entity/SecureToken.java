package com.fooddeliveryapp.foodappbackend.entity;

public class SecureToken {
}
