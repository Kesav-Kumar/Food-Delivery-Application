//package com.fooddeliveryapp.foodappbackend.service;
//
//import org.springframework.stereotype.Component;
//
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//
//@Component
//public class passwordEncoder {
//
//}